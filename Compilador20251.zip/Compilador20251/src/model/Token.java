package model;

public class Token {
    private String tipo;
    private String lexema;
    private int linha;

    public Token(String tipo, String lexema, int linha) {
        this.tipo = tipo;
        this.lexema = lexema;
        this.linha = linha;
    }

    public String getTipo() {
        return tipo;
    }

    public String getLexema() {
        return lexema;
    }

    public int getLinha() {
        return linha;
    }

    @Override
    public String toString() {
        return "[" + tipo + ": '" + lexema + "' linha " + linha + "]";
    }
}
