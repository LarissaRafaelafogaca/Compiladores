package model;

public class Operadores {
	
	public static final String[] OPERADORES = {"+", "-", "*", "/", "=", "==",
											   ">", "<", ">=", "<=", "!=", "++",
											   "--", "!", "&", "|", "%", "^", 
											   "+=", "-=", "*=", "/="};
}
