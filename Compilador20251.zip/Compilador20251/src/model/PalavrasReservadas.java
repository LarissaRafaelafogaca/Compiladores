package model;

public class PalavrasReservadas {
	public static final String[] PALAVRAS_RESERVADAS = {"int", "string", "double", "float",
														"char", "void", "if", "boolean",
														"for", "while", "case", "when",
														"then", "igor", "main", "print",
														"else", "public", "private", "type",
														"error", "break", "continue", "long",
														"true", "false"};
}
