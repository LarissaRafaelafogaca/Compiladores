package model;

public class Delimitadores {
	
	public static final int COMENTARIO_LINHA = 12;
	
	public static final String[] DELIMITADORES = {"(", ")", "[", "]", "{", "}",
												  "\"", "\'", ",", ".", ";",
												  ":", "//", "/*", "*/"};

}
