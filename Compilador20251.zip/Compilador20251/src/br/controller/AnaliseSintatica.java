package br.controller;

import java.util.List;
import java.util.Stack;

import model.Token;

public class AnaliseSintatica {
    private StringBuilder log;

    public AnaliseSintatica() {
        log = new StringBuilder();
    }

    public String analisar(List<Token> tokens) {
        log.setLength(0);

        if (tokens == null || tokens.isEmpty()) {
            log.append("Tokens vazios. Faça a análise léxica antes ou insira tokens.\n");
            return log.toString();
        }

        log.append("Iniciando análise sintática com ").append(tokens.size()).append(" tokens.\n");

        Stack<String> pilha = new Stack<>();
        int linhaAtual = 0;

        for (Token t : tokens) {
            String lex = t.getLexema();
            linhaAtual = t.getLinha();

            // Abrindo delimitadores
            if (lex.equals("{") || lex.equals("(") || lex.equals("[")) {
                pilha.push(lex);
                log.append("Linha ").append(linhaAtual).append(": Encontrado abertura '").append(lex).append("', empilhado.\n");
            }
            // Fechando delimitadores e verificando balanceamento
            else if (lex.equals("}") || lex.equals(")") || lex.equals("]")) {
                if (pilha.isEmpty()) {
                    log.append("Linha ").append(linhaAtual).append(": Erro sintático! Delimitador fechado '").append(lex).append("' sem correspondente aberto.\n");
                    return log.toString();
                }
                String aberto = pilha.pop();
                if (!corresponde(aberto, lex)) {
                    log.append("Linha ").append(linhaAtual).append(": Erro sintático! Delimitador '").append(lex)
                        .append("' não corresponde ao aberto '").append(aberto).append("'.\n");
                    return log.toString();
                }
                log.append("Linha ").append(linhaAtual).append(": Delimitador '").append(aberto).append("' fechado corretamente com '").append(lex).append("'.\n");
            }
            // Pode adicionar outras regras sintáticas específicas aqui, se quiser
        }

        if (!pilha.isEmpty()) {
            log.append("Erro sintático! Delimitadores não fechados: ");
            while (!pilha.isEmpty()) {
                log.append(pilha.pop()).append(" ");
            }
            log.append("\n");
            return log.toString();
        }

        log.append("Análise sintática concluída sem erros.\n");
        return log.toString();
    }

    private boolean corresponde(String aberto, String fechado) {
        return (aberto.equals("{") && fechado.equals("}")) ||
               (aberto.equals("(") && fechado.equals(")")) ||
               (aberto.equals("[") && fechado.equals("]"));
    }
}
