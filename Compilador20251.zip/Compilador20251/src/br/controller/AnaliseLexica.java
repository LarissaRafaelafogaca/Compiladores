package br.controller;

import java.util.ArrayList;
import java.util.List;

import model.Delimitadores;
import model.Operadores;
import model.PalavrasReservadas;
import model.Token;

public class AnaliseLexica {
    private List<Token> tokens;
    private StringBuilder log;
    private int linha;

    public AnaliseLexica() {
        tokens = new ArrayList<>();
        log = new StringBuilder();
        linha = 1;
    }

    public String analisar(String codigoFonte) {
        tokens.clear();
        log.setLength(0);
        linha = 1;

        if (codigoFonte == null || codigoFonte.trim().isEmpty()) {
            log.append("Código fonte vazio. Insira o código para análise.\n");
            return log.toString();
        }

        char[] chars = codigoFonte.toCharArray();
        int i = 0;

        while (i < chars.length) {
            char c = chars[i];

            // Ignorar espaços, tabs e nova linha
            if (c == ' ' || c == '\t') {
                i++;
                continue;
            }

            if (c == '\n') {
                linha++;
                i++;
                continue;
            }

            // Comentário de linha //
            if (c == '/' && i + 1 < chars.length && chars[i + 1] == '/') {
                log.append("Linha ").append(linha).append(": Comentário de linha iniciado.\n");
                i += 2;
                while (i < chars.length && chars[i] != '\n') i++;
                log.append("Linha ").append(linha).append(": Comentário de linha finalizado.\n");
                continue;
            }

            // Comentário de bloco /* ... */
            if (c == '/' && i + 1 < chars.length && chars[i + 1] == '*') {
                log.append("Linha ").append(linha).append(": Comentário de bloco iniciado.\n");
                i += 2;
                boolean fechou = false;
                while (i + 1 < chars.length) {
                    if (chars[i] == '*' && chars[i + 1] == '/') {
                        i += 2;
                        fechou = true;
                        break;
                    }
                    if (chars[i] == '\n') linha++;
                    i++;
                }
                if (fechou) {
                    log.append("Linha ").append(linha).append(": Comentário de bloco finalizado.\n");
                } else {
                    log.append("Erro: comentário de bloco não fechado.\n");
                    break;
                }
                continue;
            }

            // String entre aspas duplas
            if (c == '"') {
                StringBuilder str = new StringBuilder();
                str.append(c);
                i++;
                boolean fechouAspas = false;
                while (i < chars.length) {
                    str.append(chars[i]);
                    if (chars[i] == '"') {
                        fechouAspas = true;
                        i++;
                        break;
                    }
                    // Permitir \"
                    if (chars[i] == '\\' && i + 1 < chars.length && chars[i + 1] == '"') {
                        i++;
                        str.append(chars[i]);
                    }
                    i++;
                }
                if (!fechouAspas) {
                    log.append("Erro: String não fechada na linha ").append(linha).append("\n");
                    return log.toString();
                }
                tokens.add(new Token("STRING", str.toString(), linha));
                log.append("Linha ").append(linha).append(": Token STRING capturado: ").append(str).append("\n");
                continue;
            }

            // Caracter entre aspas simples
            if (c == '\'') {
                StringBuilder ch = new StringBuilder();
                ch.append(c);
                i++;
                boolean fechouAspas = false;
                while (i < chars.length) {
                    ch.append(chars[i]);
                    if (chars[i] == '\'') {
                        fechouAspas = true;
                        i++;
                        break;
                    }
                    // Permitir \'
                    if (chars[i] == '\\' && i + 1 < chars.length && chars[i + 1] == '\'') {
                        i++;
                        ch.append(chars[i]);
                    }
                    i++;
                }
                if (!fechouAspas) {
                    log.append("Erro: Char não fechado na linha ").append(linha).append("\n");
                    return log.toString();
                }
                tokens.add(new Token("CHAR", ch.toString(), linha));
                log.append("Linha ").append(linha).append(": Token CHAR capturado: ").append(ch).append("\n");
                continue;
            }

            // Delimitadores
            boolean achouDelimitador = false;
            for (String delim : Delimitadores.DELIMITADORES) {
                int len = delim.length();
                if (i + len <= chars.length) {
                    String sub = new String(chars, i, len);
                    if (sub.equals(delim)) {
                        tokens.add(new Token("DELIMITADOR", delim, linha));
                        log.append("Linha ").append(linha).append(": Token DELIMITADOR capturado: ").append(delim).append("\n");
                        i += len;
                        achouDelimitador = true;
                        break;
                    }
                }
            }
            if (achouDelimitador) continue;

            // Operadores (incluindo compostos)
            boolean achouOperador = false;
            for (String op : Operadores.OPERADORES) {
                int len = op.length();
                if (i + len <= chars.length) {
                    String sub = new String(chars, i, len);
                    if (sub.equals(op)) {
                        tokens.add(new Token("OPERADOR", op, linha));
                        log.append("Linha ").append(linha).append(": Token OPERADOR capturado: ").append(op).append("\n");
                        i += len;
                        achouOperador = true;
                        break;
                    }
                }
            }
            if (achouOperador) continue;

            // Números (inteiros e reais)
            if (Character.isDigit(c)) {
                StringBuilder numero = new StringBuilder();
                boolean ponto = false;
                while (i < chars.length && (Character.isDigit(chars[i]) || (!ponto && chars[i] == '.'))) {
                    if (chars[i] == '.') ponto = true;
                    numero.append(chars[i]);
                    i++;
                }
                tokens.add(new Token(ponto ? "REAL" : "INTEIRO", numero.toString(), linha));
                log.append("Linha ").append(linha).append(": Token ").append(ponto ? "REAL" : "INTEIRO").append(" capturado: ").append(numero).append("\n");
                continue;
            }

            // Identificadores e Palavras reservadas (começa com letra ou _)
            if (Character.isLetter(c) || c == '_') {
                StringBuilder id = new StringBuilder();
                while (i < chars.length && (Character.isLetterOrDigit(chars[i]) || chars[i] == '_')) {
                    id.append(chars[i]);
                    i++;
                }
                String idStr = id.toString();
                if (isPalavraReservada(idStr)) {
                    tokens.add(new Token("PALAVRA_RESERVADA", idStr, linha));
                    log.append("Linha ").append(linha).append(": Token PALAVRA_RESERVADA capturado: ").append(idStr).append("\n");
                } else {
                    tokens.add(new Token("IDENTIFICADOR", idStr, linha));
                    log.append("Linha ").append(linha).append(": Token IDENTIFICADOR capturado: ").append(idStr).append("\n");
                }
                continue;
            }

            // Se chegou aqui, é caractere inválido
            log.append("Linha ").append(linha).append(": Caractere inválido encontrado: '").append(c).append("'\n");
            i++;
        }

        log.append("Análise Léxica finalizada com ").append(tokens.size()).append(" tokens.\n");
        return log.toString();
    }

    private boolean isPalavraReservada(String s) {
        for (String pr : PalavrasReservadas.PALAVRAS_RESERVADAS) {
            if (pr.equals(s)) return true;
        }
        return false;
    }

    public List<Token> getTokens() {
        return tokens;
    }
}
