package br.view;

import br.controller.AnaliseLexica;
import br.controller.AnaliseSintatica;
import model.Token;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class TelaCompilador extends JFrame {

    private JTextArea txtFonte;
    private JTextArea txtLog;
    private JButton btnAnaliseLexica;
    private JButton btnAnaliseSintatica;

    private List<Token> tokensParaSintatica;

    public TelaCompilador() {
        setTitle("Compilador - Análise Léxica e Sintática");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1000, 600);
        setLocationRelativeTo(null);
        initComponents();
    }

    private void initComponents() {
        // Usar BorderLayout para organizar o frame principal
        setLayout(new BorderLayout(10, 10));

        // Painel central para os dois JTextArea lado a lado
        JPanel painelCentral = new JPanel(new GridLayout(1, 2, 10, 10));

        // Área para o código fonte (entrada)
        txtFonte = new JTextArea();
        txtFonte.setFont(new Font("Monospaced", Font.PLAIN, 14));
        JScrollPane scrollFonte = new JScrollPane(txtFonte);
        scrollFonte.setBorder(BorderFactory.createTitledBorder("Código Fonte"));

        // Área para o log da análise (saída)
        txtLog = new JTextArea();
        txtLog.setFont(new Font("Monospaced", Font.PLAIN, 14));
        txtLog.setEditable(false);
        JScrollPane scrollLog = new JScrollPane(txtLog);
        scrollLog.setBorder(BorderFactory.createTitledBorder("Log da Análise"));

        // Adiciona as duas áreas lado a lado no painel central
        painelCentral.add(scrollFonte);
        painelCentral.add(scrollLog);

        // Painel inferior para os botões
        JPanel painelBotoes = new JPanel();
        btnAnaliseLexica = new JButton("Análise Léxica");
        btnAnaliseSintatica = new JButton("Análise Sintática");
        painelBotoes.add(btnAnaliseLexica);
        painelBotoes.add(btnAnaliseSintatica);

        // Adiciona componentes na janela
        add(painelCentral, BorderLayout.CENTER);
        add(painelBotoes, BorderLayout.SOUTH);

        // Ação do botão Análise Léxica
        btnAnaliseLexica.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                executarAnaliseLexica();
            }
        });

        // Ação do botão Análise Sintática
        btnAnaliseSintatica.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                executarAnaliseSintatica();
            }
        });
    }

    private void executarAnaliseLexica() {
        String codigo = txtFonte.getText();
        AnaliseLexica analiseLexica = new AnaliseLexica();
        String log = analiseLexica.analisar(codigo);
        tokensParaSintatica = analiseLexica.getTokens();
        txtLog.setText(log);
    }

    private void executarAnaliseSintatica() {
        if (tokensParaSintatica == null || tokensParaSintatica.isEmpty()) {
            txtLog.setText("Faça a análise léxica primeiro para gerar os tokens.\n");
            return;
        }
        AnaliseSintatica analiseSintatica = new AnaliseSintatica();
        String log = analiseSintatica.analisar(tokensParaSintatica);
        txtLog.setText(log);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new TelaCompilador().setVisible(true);
        });
    }
}
